#############################################################################
##
#W  nor2.c                 GAP library of groups           Hans Ulrich Besche
##                                               Bettina Eick, Eamonn O'Brien
##

SMALL_GROUP_LIB[ 3 ] := [
[ 1, 3, 5, -1 ], 
[ 1, 8 ], 
[ 1 ] ];
