#############################################################################
##
#W  nor7.c                 GAP library of groups           Hans Ulrich Besche
##                                               Bettina Eick, Eamonn O'Brien
##

SMALL_GROUP_LIB[ 245 ] := [
[ [ 1 ], [ 1, 7 ], -1, [ 1, -2, -3, -4, -5, -6, 7 ], -1 ], 
[ [ 1 ], [ 49 ] ], 
[ [ 1 ] ] ];
