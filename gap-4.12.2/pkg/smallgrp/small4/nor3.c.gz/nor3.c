#############################################################################
##
#W  nor3.c                 GAP library of groups           Hans Ulrich Besche
##                                               Bettina Eick, Eamonn O'Brien
##

SMALL_GROUP_LIB[ 45 ] := [
[ [ 1 ], [ 1, 3 ], -1, [ 1, -2, 3 ], -1 ], 
[ [ 1 ], [ 9 ] ], 
[ [ 1 ] ] ];
